package io.michaelcane;

/**
 * This App.java will run the program as well as the
 * functions that make this Calculator possible.
 */
public class App {
    public static void main(String[] args) {

        Calculator calculator = new Calculator();
    }
}
